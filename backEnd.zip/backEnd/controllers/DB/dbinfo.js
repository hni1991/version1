const dbinfo = {
  user: "b0jOBf24FV",
  database: "b0jOBf24FV",
  Password: "bjYIsUIgcT",
  host: "remotemysql.com",
  Port: 3306
};
module.exports = dbinfo;
